﻿#Written By#
#Prabhat Nigam - Microsoft Solution Archtitect#
#Microsoft Profile - http://social.technet.microsoft.com/profile/prabhatnigam/#
$SearchTerm = Read-Host "Enter the search term: "
$SearchString = '*'+$SearchTerm+'*'
Get-TransportRule | ? {$_.Description -like $SearchString}